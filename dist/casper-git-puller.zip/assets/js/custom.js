$(document).ready(function() {
  $(document).on('click', '#icon-close-menu', function() {
  	$('#menu-mobile').hide();
  });

  $(document).on('click', '.hamburger-menu', function() {
  	console.log('RADI!!')
  	$('#menu-mobile').show();
  });
});
